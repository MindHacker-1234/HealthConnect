/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function() {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */




    // const patient = $scope.Widgets.checkbox2;
    // const doctor = $scope.Widgets.checkbox3

    // const submitbutton = $scope.Widgets.button3;

    // Page.button3Click = function($event, widget) {
    //     if (patient.checked) {
    //         $scope.goToPage('Registration');
    //     } else if (doctor.checked) {
    //         $scope.goToPage('doctorRegistration');
    //     } else {
    //         alert('please select either patient or doctor');
    //     }

    // };
};