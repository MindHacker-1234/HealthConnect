This folder has jar dependencies of prefab
