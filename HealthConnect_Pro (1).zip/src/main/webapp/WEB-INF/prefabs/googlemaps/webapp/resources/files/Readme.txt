Use this folder to add your project resources such as text files, pdfs, docs, subtitle sources etc.
